import { useContext, useEffect, useRef } from "react";
import TestCaseCard from "./TestCaseCard";
import { ListOfTestCasesDataContext } from "../../App";
import { ClipboardContext } from "./Create";
import cloneDeep from 'lodash/cloneDeep';

export default function RightMain(){
    const { listOfTestCasesData, setListOfTestCasesData } = useContext(ListOfTestCasesDataContext);
    
     const containerRef = useRef(null);
     const prevContainerLengthRef = useRef(listOfTestCasesData?.length);

     const {clipboardTestCaseData, setClipboardTestCaseData} = useContext(ClipboardContext);
        console.log("clipboad", clipboardTestCaseData);
    useEffect(() => {
        const c = containerRef.current;
        if (!c) return;

        const prevLength = prevContainerLengthRef.current;
        const currLength = listOfTestCasesData.length;

        if(currLength>prevLength){
        // ensure DOM painted before scrolling
        requestAnimationFrame(() => {
            c.scrollTo({ top: c.scrollHeight, behavior: 'smooth' });
            });
        }
        prevContainerLengthRef.current=currLength;
    }, [listOfTestCasesData?.length]);

    const onDelete = (testCaseNum) => {
        let newTCsDataList = [];
        setListOfTestCasesData(prev=>{
            newTCsDataList = prev.filter((_, idx)=>{
                return idx!==testCaseNum;
            })
            return newTCsDataList;
        })
    }

    const onCopy = (testCaseNum) => {
            const copy = cloneDeep(listOfTestCasesData[testCaseNum]);
            copy.testCaseIndex = "";
            console.log("is it original", copy == listOfTestCasesData[testCaseNum])
            setClipboardTestCaseData(copy);
      
    }

    const onEdit = (testCaseNum) => {
            const copy = cloneDeep(listOfTestCasesData[testCaseNum]);
            console.log("is it original", copy == listOfTestCasesData[testCaseNum])
            setClipboardTestCaseData(copy);
      
    }

    
    return(
        <div ref={containerRef} className="overflow-y-auto overflow-x-hidden max-h-full">
            {listOfTestCasesData?.length != 0 && listOfTestCasesData?.map((testCaseData, idx)=>{
                return <TestCaseCard testCaseData={testCaseData} testCaseNum={idx} onDelete={(testCaseNum)=>onDelete(testCaseNum)} onCopy={(testCaseNum)=>onCopy(testCaseNum)} onEdit={(testCaseNum) => onEdit(testCaseNum)}/>
            })}

            {
                listOfTestCasesData.length == 0 &&
                 <div className="text-center text-lg text-slate-400 "> No test case created yet. </div>
            }

            {/* <TestCaseCard />
          <TestCaseCard />  */}
        </div>
    )
}