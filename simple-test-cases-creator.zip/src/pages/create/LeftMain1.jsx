export default function LeftMain1(){

    return(
        <>
        <main className="mx-auto max-w-3xl px-4 pt-20 pb-24 ">
        <header className="mb-6">
          <h2 className="text-2xl font-semibold">Fields</h2>
          <p className="text-sm text-slate-600">This list stays under the top navigation bar. Open/close the bar to see it fold from the top.</p>
        </header>

        <ul className="space-y-3">
          {Array.from({ length: 16 }).map((_, i) => (
            <li
              key={i}
              className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"
            >
              <label className="block text-sm font-medium text-slate-700">Field {i + 1}</label>
              <input
                type="text"
                placeholder={`Enter value for field ${i + 1}`}
                className="mt-2 w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-400"
              />
            </li>
          ))}
        </ul>
      </main>
      </>
    )
};
