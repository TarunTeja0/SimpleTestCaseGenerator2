import { createContext, useContext, useState } from "react";
import { TestCaseFileNameContext } from "../../App";
import TopFoldNavSheet from "./TopFoldNavSheet";
import LeftMain from "./LeftMain";
import RightMain from "./RightMain";

export const ClipboardContext = createContext();

export default function Create(){
    const {testCaseFileName, saveTestCaseFileNameFunc} = useContext(TestCaseFileNameContext);
    const [clipboardTestCaseData, setClipboardTestCaseData] = useState(null);



    return(
        // <div>{testCaseFileName}</div>
        <div>
            <ClipboardContext.Provider value={{clipboardTestCaseData, setClipboardTestCaseData}}>
                <TopFoldNavSheet LeftMain={LeftMain} RightMain={RightMain} />
            </ClipboardContext.Provider>
        </div>
    )
}