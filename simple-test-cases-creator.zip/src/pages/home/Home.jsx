// src/pages/Home.js
import React, { useState } from "react";
import Dialog from "./Dialog";

export default function Home() {
    const [openDialog, setOpenDialog] = useState(false);

  const cards = [
    { id: 1, title: "Card 1", description: "This is card one." },
    { id: 2, title: "Card 2", description: "This is card two." },
    { id: 3, title: "Card 3", description: "This is card three." },
  ];

  return (
    <div className="relative min-h-screen bg-gray-50 p-6">
      {/* Title */}
      <h1 className="text-3xl font-bold text-center mb-16 text-gray-800">
        My Home Page
      </h1>

      {/* Cards */}
      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {cards.map((card) => (
          <div
            key={card.id}
            className="bg-white rounded-xl shadow-md p-6 hover:scale-[1.02] transition-transform"
          >
            <h3 className="text-xl font-semibold mb-2 text-gray-700">
              {card.title}
            </h3>
            <p className="text-gray-600">{card.description}</p>
          </div>
        ))}
      </div>

      {/* Floating + button */}
      <button className="fixed bottom-6 right-6 bg-blue-600 hover:bg-blue-700 text-white text-3xl w-14 h-14 rounded-full shadow-lg flex items-center justify-center"
                onClick={()=>setOpenDialog(prevState => !prevState)}
      >
        +
      </button>

        <Dialog open={openDialog} onClose={()=>setOpenDialog(prevState => !prevState)} />


    </div>
  );
}
